<?php
// ThinkPHP 8 应用配置
return [
    // 应用命名空间（composer psr-4 映射：app\ => application/）
    'app_namespace'   => 'app',

    // 开启路由
    'with_route'      => true,

    // 关闭控制器快速访问（仅允许显式路由）
    'app_express'     => false,

    // 默认应用（单应用模式）
    'default_app'     => 'index',

    // 异常页面不显示详细信息
    'show_error_msg'  => false,

    // 默认时区
    'default_timezone' => 'Asia/Shanghai',
];
